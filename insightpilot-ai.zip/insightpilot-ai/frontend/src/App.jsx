import { Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { DatasetProvider } from "./context/DatasetContext";
import ProtectedRoute from "./components/common/ProtectedRoute";

import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Datasets from "./pages/Datasets";
import Dashboard from "./pages/Dashboard";
import Copilot from "./pages/Copilot";
import DAXCopilot from "./pages/DAXCopilot";
import Anomalies from "./pages/Anomalies";
import Forecast from "./pages/Forecast";
import Customers from "./pages/Customers";
import Reports from "./pages/Reports";

export default function App() {
  return (
    <AuthProvider>
      <DatasetProvider>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/datasets" element={<ProtectedRoute><Datasets /></ProtectedRoute>} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/copilot" element={<ProtectedRoute><Copilot /></ProtectedRoute>} />
          <Route path="/dax" element={<ProtectedRoute><DAXCopilot /></ProtectedRoute>} />
          <Route path="/anomalies" element={<ProtectedRoute><Anomalies /></ProtectedRoute>} />
          <Route path="/forecast" element={<ProtectedRoute><Forecast /></ProtectedRoute>} />
          <Route path="/customers" element={<ProtectedRoute><Customers /></ProtectedRoute>} />
          <Route path="/reports" element={<ProtectedRoute><Reports /></ProtectedRoute>} />
        </Routes>
      </DatasetProvider>
    </AuthProvider>
  );
}
