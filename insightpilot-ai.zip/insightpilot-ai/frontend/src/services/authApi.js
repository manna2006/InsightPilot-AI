import api from "./api";

export const register = (email, password, full_name) =>
  api.post("/api/auth/register", { email, password, full_name }).then((r) => r.data);

export const login = (email, password) =>
  api.post("/api/auth/login", { email, password }).then((r) => r.data);
