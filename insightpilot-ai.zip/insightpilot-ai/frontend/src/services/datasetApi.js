import api from "./api";

export const uploadDataset = (file, onProgress) => {
  const form = new FormData();
  form.append("file", file);
  return api.post("/api/datasets/upload", form, {
    headers: { "Content-Type": "multipart/form-data" },
    onUploadProgress: (e) => onProgress?.(Math.round((e.loaded / e.total) * 100)),
  }).then((r) => r.data);
};

export const listDatasets = () => api.get("/api/datasets").then((r) => r.data);
export const getDataset = (id) => api.get(`/api/datasets/${id}`).then((r) => r.data);
export const getProfile = (id) => api.get(`/api/datasets/${id}/profile`).then((r) => r.data);
export const getCleaningSuggestions = (id) => api.get(`/api/datasets/${id}/cleaning-suggestions`).then((r) => r.data);
export const applyCleaning = (id, accepted_actions) => api.post(`/api/datasets/${id}/clean`, { dataset_id: id, accepted_actions }).then((r) => r.data);
export const getAnalytics = (id) => api.get(`/api/datasets/${id}/analytics`).then((r) => r.data);
export const detectAnomalies = (id, method = "zscore") => api.post(`/api/anomalies/detect/${id}?method=${method}`).then((r) => r.data);
export const getForecast = (id, horizon_days = 30) => api.post(`/api/forecast/${id}?horizon_days=${horizon_days}`).then((r) => r.data);
export const getRFM = (id) => api.post(`/api/customers/rfm/${id}`).then((r) => r.data);
