import api from "./api";

export const generateReport = (dataset_id) =>
  api.post("/api/reports/generate", { dataset_id }).then((r) => r.data);
