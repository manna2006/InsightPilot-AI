import api from "./api";

export const askCopilot = (dataset_id, question, session_id) =>
  api.post("/api/copilot/chat", { dataset_id, question, session_id }).then((r) => r.data);

export const generateSql = (dataset_id, question) =>
  api.post("/api/copilot/sql", { dataset_id, question }).then((r) => r.data);

export const generateInsights = (dataset_id, question = "Summarize this dataset") =>
  api.post("/api/copilot/insights", { dataset_id, question }).then((r) => r.data);

export const runDax = (mode, input_text) =>
  api.post("/api/dax", { mode, input_text }).then((r) => r.data);
