export default function Badge({ children, color = "#34C7B5" }) {
  return (
    <span
      className="font-mono text-[10.5px] px-2.5 py-1 rounded-full"
      style={{ color, border: `1px solid ${color}55`, background: `${color}18` }}
    >
      {children}
    </span>
  );
}
