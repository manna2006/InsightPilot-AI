export default function ChartCard({ title, right, children }) {
  return (
    <div className="bg-surface border border-white/10 rounded-xl p-5">
      <div className="flex items-center justify-between mb-3.5">
        <h3 className="font-display text-sm font-semibold">{title}</h3>
        {right}
      </div>
      {children}
    </div>
  );
}
