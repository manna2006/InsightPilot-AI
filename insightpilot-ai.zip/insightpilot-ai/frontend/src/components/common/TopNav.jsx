import { NavLink, useNavigate } from "react-router-dom";
import { LayoutDashboard, MessageSquare, Code2, AlertTriangle, TrendingUp, Users, FileText, Database, LogOut } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useDataset } from "../../context/DatasetContext";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/copilot", label: "AI Copilot", icon: MessageSquare },
  { to: "/dax", label: "DAX Copilot", icon: Code2 },
  { to: "/anomalies", label: "Anomalies", icon: AlertTriangle },
  { to: "/forecast", label: "Forecast", icon: TrendingUp },
  { to: "/customers", label: "Customers", icon: Users },
  { to: "/reports", label: "Reports", icon: FileText },
];

export default function TopNav() {
  const { logout } = useAuth();
  const { activeDataset } = useDataset();
  const navigate = useNavigate();

  return (
    <div className="sticky top-0 z-20 bg-ink border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6 py-3 flex items-center gap-6 flex-wrap">
        <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => navigate("/dashboard")}>
          <div className="w-7 h-7 rounded-md bg-gradient-to-br from-yellow to-[#C9A20E] flex items-center justify-center text-ink font-bold text-[11px]">IP</div>
          <span className="font-display font-bold text-[13px]">INSIGHTPILOT</span>
        </div>
        <div className="flex gap-1 overflow-x-auto flex-1">
          {NAV.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} className={({ isActive }) =>
              `px-3.5 py-2 rounded-lg text-[13px] font-semibold flex items-center gap-1.5 whitespace-nowrap border ${
                isActive ? "bg-surfaceAlt text-yellow border-white/15" : "text-slate-400 border-transparent hover:text-white"
              }`
            }>
              <Icon size={14} /> {label}
            </NavLink>
          ))}
        </div>
        <div className="flex items-center gap-3 text-right">
          <div className="font-mono text-[11px] text-slate-500">
            {activeDataset ? `${activeDataset.name} · ${activeDataset.row_count} rows` : (
              <NavLink to="/datasets" className="text-yellow">Upload dataset →</NavLink>
            )}
          </div>
          <button onClick={logout} className="text-slate-400 hover:text-white" title="Log out"><LogOut size={16} /></button>
        </div>
      </div>
    </div>
  );
}
