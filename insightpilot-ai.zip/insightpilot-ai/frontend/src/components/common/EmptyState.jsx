export default function EmptyState({ title, subtitle, action }) {
  return (
    <div className="text-center py-16 text-slate-500">
      <div className="font-display text-base text-white mb-1.5">{title}</div>
      {subtitle && <p className="text-sm max-w-md mx-auto">{subtitle}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
