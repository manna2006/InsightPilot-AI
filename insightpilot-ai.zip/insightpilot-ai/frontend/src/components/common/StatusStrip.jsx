import { Loader2 } from "lucide-react";
export default function StatusStrip({ text }) {
  if (!text) return null;
  return (
    <div className="font-mono text-xs text-teal flex items-center gap-2 py-2 animate-pulse">
      <Loader2 size={13} /> {text}
    </div>
  );
}
