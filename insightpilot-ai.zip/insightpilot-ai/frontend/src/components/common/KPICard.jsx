export default function KPICard({ label, value, delta, deltaUp }) {
  return (
    <div className="bg-surface border border-white/10 rounded-xl p-4">
      <div className="font-mono text-[10.5px] text-slate-500 uppercase tracking-wide">{label}</div>
      <div className="font-display text-xl font-semibold mt-1.5">{value}</div>
      {delta && (
        <div className={`text-[11.5px] mt-1 ${deltaUp ? "text-teal" : "text-coral"}`}>
          {deltaUp ? "▲" : "▼"} {delta}
        </div>
      )}
    </div>
  );
}
