import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import TopNav from "../components/common/TopNav";
import Badge from "../components/common/Badge";
import EmptyState from "../components/common/EmptyState";
import { useDataset } from "../context/DatasetContext";
import * as datasetApi from "../services/datasetApi";
import { fmtINR } from "../lib/format";

const SEV_COLOR = { Critical: "#FF6B5E", High: "#FF9A5A", Medium: "#F2C811", Low: "#8B93A7" };

export default function Anomalies() {
  const { activeDataset } = useDataset();
  const [method, setMethod] = useState("zscore");
  const [anomalies, setAnomalies] = useState(null);

  useEffect(() => {
    if (!activeDataset) return;
    datasetApi.detectAnomalies(activeDataset.id, method).then((r) => setAnomalies(r.anomalies));
  }, [activeDataset, method]);

  if (!activeDataset) return <Navigate to="/datasets" replace />;

  return (
    <div className="min-h-screen bg-ink text-white">
      <TopNav />
      <div className="max-w-4xl mx-auto px-6 py-8">
        <h1 className="font-display text-xl font-semibold mb-1">Anomaly detection</h1>
        <p className="text-slate-400 text-sm mb-5">Flags months where revenue deviates significantly from the trailing average.</p>

        <div className="flex gap-2 mb-5">
          {[["zscore", "Z-Score"], ["iqr", "IQR"], ["isolation_forest", "Isolation Forest"]].map(([id, label]) => (
            <div key={id} onClick={() => setMethod(id)}
              className={`px-3.5 py-2 rounded-lg text-[13px] font-semibold cursor-pointer border ${method === id ? "bg-surfaceAlt text-yellow border-white/15" : "text-slate-400 border-white/10"}`}>
              {label}
            </div>
          ))}
        </div>

        <div className="bg-surface border border-white/10 rounded-xl overflow-hidden">
          {!anomalies ? (
            <div className="p-8 text-center text-slate-500 text-sm">Loading...</div>
          ) : anomalies.length === 0 ? (
            <EmptyState title="No anomalies detected" subtitle="Revenue stayed within the expected range for every period with this method." />
          ) : (
            <table className="w-full text-[13px] border-collapse">
              <thead>
                <tr>{["Period", "Revenue", "Expected Range", "Severity", "Reason"].map((h) => (
                  <th key={h} className="text-left px-4 py-2.5 font-mono text-[10.5px] text-slate-500 uppercase border-b border-white/10">{h}</th>
                ))}</tr>
              </thead>
              <tbody>
                {anomalies.map((a, i) => (
                  <tr key={i}>
                    <td className="px-4 py-2.5 border-b border-white/10">{a.period}</td>
                    <td className="px-4 py-2.5 border-b border-white/10">{fmtINR(a.value)}</td>
                    <td className="px-4 py-2.5 border-b border-white/10 font-mono text-[11.5px] text-slate-400">{fmtINR(a.expected_range[0])} – {fmtINR(a.expected_range[1])}</td>
                    <td className="px-4 py-2.5 border-b border-white/10"><Badge color={SEV_COLOR[a.severity]}>{a.severity}</Badge></td>
                    <td className="px-4 py-2.5 border-b border-white/10 text-slate-400">{a.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
