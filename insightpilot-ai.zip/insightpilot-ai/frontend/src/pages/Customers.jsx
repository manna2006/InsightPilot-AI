import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import TopNav from "../components/common/TopNav";
import ChartCard from "../components/common/ChartCard";
import Badge from "../components/common/Badge";
import { useDataset } from "../context/DatasetContext";
import * as datasetApi from "../services/datasetApi";
import { fmtINR } from "../lib/format";

const SEG_COLOR = { Champions: "#F2C811", "Loyal Customers": "#34C7B5", "Potential Loyalists": "#6C8CFF", "New Customers": "#B892FF", "At Risk": "#FF9A5A", Lost: "#FF6B5E", Others: "#8B93A7" };

export default function Customers() {
  const { activeDataset } = useDataset();
  const [rfm, setRfm] = useState(null);

  useEffect(() => {
    if (!activeDataset) return;
    datasetApi.getRFM(activeDataset.id).then(setRfm);
  }, [activeDataset]);

  if (!activeDataset) return <Navigate to="/datasets" replace />;
  if (!rfm) return (<div className="min-h-screen bg-ink text-white"><TopNav /><div className="max-w-5xl mx-auto px-6 py-10 text-slate-400">Computing RFM segments...</div></div>);

  return (
    <div className="min-h-screen bg-ink text-white">
      <TopNav />
      <div className="max-w-5xl mx-auto px-6 py-8">
        <h1 className="font-display text-xl font-semibold mb-1">RFM segmentation</h1>
        <p className="text-slate-400 text-sm mb-5">Recency, Frequency, and Monetary scoring, quantile-based across all customers.</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
          {rfm.segments.map((s) => (
            <div key={s.segment} className="bg-surface border border-white/10 rounded-xl p-4" style={{ borderLeft: `3px solid ${SEG_COLOR[s.segment] || "#8B93A7"}` }}>
              <div className="font-mono text-[10.5px] text-slate-500 uppercase">{s.segment}</div>
              <div className="font-display text-lg mt-1.5">{s.count} customers</div>
              <div className="text-[11.5px] text-slate-400 mt-0.5">{fmtINR(s.revenue)} total</div>
            </div>
          ))}
        </div>

        <ChartCard title="Revenue by Segment">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={rfm.segments}>
              <CartesianGrid stroke="rgba(255,255,255,0.08)" vertical={false} />
              <XAxis dataKey="segment" stroke="#5C6478" fontSize={10.5} angle={-15} textAnchor="end" height={60} />
              <YAxis stroke="#5C6478" fontSize={11} tickFormatter={fmtINR} width={70} />
              <Tooltip contentStyle={{ background: "#212C43", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 8, fontSize: 12 }} formatter={fmtINR} />
              <Bar dataKey="revenue" radius={[4, 4, 0, 0]}>
                {rfm.segments.map((s, i) => <Cell key={i} fill={SEG_COLOR[s.segment] || "#8B93A7"} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <div className="bg-surface border border-white/10 rounded-xl overflow-hidden mt-4">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr>{["Customer", "Orders", "Revenue", "Recency (days)", "Segment"].map((h) => (
                <th key={h} className="text-left px-3.5 py-2.5 font-mono text-[10.5px] text-slate-500 uppercase border-b border-white/10">{h}</th>
              ))}</tr>
            </thead>
            <tbody>
              {rfm.customers.slice(0, 12).map((c) => (
                <tr key={c.Customer_ID}>
                  <td className="px-3.5 py-2 border-b border-white/10">{c.Customer_ID}</td>
                  <td className="px-3.5 py-2 border-b border-white/10 text-slate-400">{c.frequency}</td>
                  <td className="px-3.5 py-2 border-b border-white/10">{fmtINR(c.monetary)}</td>
                  <td className="px-3.5 py-2 border-b border-white/10 text-slate-400">{c.recency_days}</td>
                  <td className="px-3.5 py-2 border-b border-white/10"><Badge color={SEG_COLOR[c.segment] || "#8B93A7"}>{c.segment}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
