import { useState } from "react";
import { Navigate } from "react-router-dom";
import { FileText, Download, Loader2 } from "lucide-react";
import TopNav from "../components/common/TopNav";
import StatusStrip from "../components/common/StatusStrip";
import { useDataset } from "../context/DatasetContext";
import * as reportApi from "../services/reportApi";

function renderMarkdown(text) {
  return text.split("\n").map((line, i) => {
    if (line.startsWith("## ")) return <h3 key={i} className="font-display text-base mt-5 mb-2">{line.slice(3)}</h3>;
    if (line.trim().startsWith("- ")) return <div key={i} className="text-sm text-slate-400 mb-1 pl-3">· {line.trim().slice(2)}</div>;
    if (!line.trim()) return <div key={i} className="h-1.5" />;
    return <p key={i} className="text-sm text-slate-400 mb-2">{line}</p>;
  });
}

export default function Reports() {
  const { activeDataset } = useDataset();
  const [report, setReport] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  if (!activeDataset) return <Navigate to="/datasets" replace />;

  async function generate() {
    setLoading(true); setErr(""); setReport("");
    try {
      const res = await reportApi.generateReport(activeDataset.id);
      setReport(res.content_markdown);
    } catch (e) {
      setErr(e.response?.data?.detail || "Could not generate the report.");
    } finally {
      setLoading(false);
    }
  }

  function download() {
    const blob = new Blob([report], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "insightpilot-executive-report.md"; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-screen bg-ink text-white">
      <TopNav />
      <div className="max-w-3xl mx-auto px-6 py-8">
        <h1 className="font-display text-xl font-semibold mb-1">Executive report generator</h1>
        <p className="text-slate-400 text-sm mb-5">Compiles KPIs, RFM segments, anomalies, and forecast trend into a written report.</p>

        <div className="flex gap-2.5 mb-5">
          <button onClick={generate} disabled={loading} className="px-4 py-2.5 rounded-lg bg-yellow text-ink font-semibold text-sm flex items-center gap-2">
            {loading ? <Loader2 size={15} className="animate-spin" /> : <FileText size={15} />} {loading ? "Generating..." : "Generate Executive Report"}
          </button>
          {report && <button onClick={download} className="px-4 py-2.5 rounded-lg border border-white/15 font-semibold text-sm flex items-center gap-2"><Download size={15} /> Download .md</button>}
        </div>

        {err && <div className="text-coral text-sm mb-4">{err}</div>}
        {loading && <StatusStrip text="Compiling verified metrics into a narrative report..." />}
        {report && <div className="bg-surface border border-white/10 rounded-xl p-7">{renderMarkdown(report)}</div>}
      </div>
    </div>
  );
}
