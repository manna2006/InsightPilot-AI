import { useState } from "react";
import { Wand2, Info, Bug, Gauge, Sparkles, Loader2 } from "lucide-react";
import TopNav from "../components/common/TopNav";
import * as copilotApi from "../services/copilotApi";

const MODES = [
  { id: "generate", label: "Generate", icon: Wand2 },
  { id: "explain", label: "Explain", icon: Info },
  { id: "debug", label: "Debug", icon: Bug },
  { id: "optimize", label: "Optimize", icon: Gauge },
];

export default function DAXCopilot() {
  const [mode, setMode] = useState("generate");
  const [input, setInput] = useState("Calculate year-over-year revenue growth.");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  async function run() {
    setLoading(true); setErr(""); setResult(null);
    try {
      const res = await copilotApi.runDax(mode, input);
      setResult(res);
    } catch (e) {
      setErr(e.response?.data?.detail || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-ink text-white">
      <TopNav />
      <div className="max-w-3xl mx-auto px-6 py-8">
        <h1 className="font-display text-xl font-semibold mb-1">DAX Copilot</h1>
        <p className="text-slate-400 text-sm mb-5">Generate, explain, debug, and optimize DAX against a documented star schema.</p>

        <div className="flex gap-2 mb-4">
          {MODES.map(({ id, label, icon: Icon }) => (
            <div key={id} onClick={() => setMode(id)}
              className={`px-3.5 py-2 rounded-lg text-[13px] font-semibold flex items-center gap-1.5 cursor-pointer border ${mode === id ? "bg-surfaceAlt text-yellow border-white/15" : "text-slate-400 border-white/10"}`}>
              <Icon size={14} /> {label}
            </div>
          ))}
        </div>

        <textarea className="w-full bg-surfaceAlt border border-white/15 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-yellow"
          style={{ minHeight: mode === "generate" ? 70 : 130, fontFamily: mode === "generate" ? "inherit" : "'JetBrains Mono',monospace" }}
          value={input} onChange={(e) => setInput(e.target.value)}
          placeholder={mode === "generate" ? "Describe the measure you need..." : `Paste the DAX to ${mode}...`} />

        <button onClick={run} disabled={loading} className="mt-3 px-4 py-2.5 rounded-lg bg-yellow text-ink font-semibold text-sm flex items-center gap-2">
          {loading ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />} {loading ? "Working..." : "Run"}
        </button>

        {err && <div className="text-coral text-sm mt-4">{err}</div>}

        {result && (
          <div className="mt-6">
            <div className="font-mono text-[11px] text-slate-500 uppercase mb-2">DAX</div>
            <pre className="font-mono text-[13px] text-teal bg-surface border border-white/10 rounded-xl p-4 overflow-x-auto whitespace-pre-wrap">{result.dax}</pre>
            {result.explanation && (
              <>
                <div className="font-mono text-[11px] text-slate-500 uppercase mt-5 mb-2">Explanation</div>
                <p className="text-sm text-slate-400">{result.explanation}</p>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
