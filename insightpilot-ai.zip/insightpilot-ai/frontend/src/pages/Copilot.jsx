import { useEffect, useRef, useState } from "react";
import { Navigate } from "react-router-dom";
import { Send } from "lucide-react";
import TopNav from "../components/common/TopNav";
import StatusStrip from "../components/common/StatusStrip";
import { useDataset } from "../context/DatasetContext";
import * as copilotApi from "../services/copilotApi";

const SUGGESTED = [
  "What is total revenue and profit?",
  "Which region performs best?",
  "Show me the monthly revenue trend.",
  "Who are our top 5 customers?",
];

export default function Copilot() {
  const { activeDataset } = useDataset();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [status, setStatus] = useState(null);
  const scrollRef = useRef(null);

  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" }); }, [messages, status]);

  if (!activeDataset) return <Navigate to="/datasets" replace />;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function ask(question) {
    if (!question.trim()) return;
    setMessages((m) => [...m, { role: "user", text: question }]);
    setInput("");
    setStatus("Understanding your question...");
    await sleep(400);
    setStatus("Analyzing dataset...");
    try {
      const res = await copilotApi.askCopilot(activeDataset.id, question);
      setStatus(null);
      setMessages((m) => [...m, { role: "assistant", text: res.answer, question, suggestions: res.suggested_questions }]);
    } catch (err) {
      setStatus(null);
      setMessages((m) => [...m, { role: "assistant", error: err.response?.data?.detail || "Something went wrong." }]);
    }
  }

  async function showSql(question) {
    setStatus("Generating SQL...");
    try {
      const res = await copilotApi.generateSql(activeDataset.id, question);
      setMessages((m) => [...m, { role: "assistant", codeBlock: res.sql }]);
    } catch (err) {
      setMessages((m) => [...m, { role: "assistant", error: err.response?.data?.detail || "Could not generate SQL." }]);
    } finally {
      setStatus(null);
    }
  }

  return (
    <div className="min-h-screen bg-ink text-white flex flex-col">
      <TopNav />
      <div className="max-w-3xl w-full mx-auto px-6 py-6 flex flex-col flex-1">
        <h1 className="font-display text-xl font-semibold mb-1">Ask your data</h1>
        <p className="text-slate-400 text-sm mb-4">Grounded in {activeDataset.name} — never raw rows, never invented numbers.</p>

        <div ref={scrollRef} className="flex-1 overflow-y-auto bg-surface border border-white/10 rounded-xl p-5 mb-4">
          {messages.length === 0 && (
            <div className="flex flex-wrap gap-2">
              {SUGGESTED.map((q) => (
                <span key={q} onClick={() => ask(q)} className="font-mono text-xs text-teal border border-teal/30 bg-teal/10 px-3 py-2 rounded-lg cursor-pointer">{q}</span>
              ))}
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className="mb-4 flex gap-3 items-start">
              <div className={`w-6 h-6 rounded-md flex-shrink-0 flex items-center justify-center text-[11px] font-mono ${m.role === "user" ? "bg-surfaceAlt text-slate-400" : "bg-yellow text-ink"}`}>
                {m.role === "user" ? "DA" : "AI"}
              </div>
              <div className="flex-1">
                {m.text && <div className="text-sm">{m.text}</div>}
                {m.error && <div className="text-coral text-sm">{m.error}</div>}
                {m.codeBlock && <pre className="font-mono text-xs bg-surfaceAlt border border-white/10 rounded-lg px-3 py-2.5 mt-2 overflow-x-auto text-teal">{m.codeBlock}</pre>}
                {m.role === "assistant" && m.question && (
                  <span onClick={() => showSql(m.question)} className="inline-block mt-2 font-mono text-[11px] text-slate-400 border border-white/10 px-2.5 py-1 rounded-md cursor-pointer">Show SQL</span>
                )}
              </div>
            </div>
          ))}
          <StatusStrip text={status} />
        </div>

        <div className="flex gap-2.5">
          <input className="flex-1 bg-surfaceAlt border border-white/15 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-yellow"
            placeholder="Ask a question about your data..." value={input}
            onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && ask(input)} />
          <button onClick={() => ask(input)} disabled={!!status} className="px-4 rounded-lg bg-yellow text-ink"><Send size={16} /></button>
        </div>
      </div>
    </div>
  );
}
