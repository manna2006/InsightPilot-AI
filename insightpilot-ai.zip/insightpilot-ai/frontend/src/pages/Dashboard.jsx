import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { RefreshCw } from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import TopNav from "../components/common/TopNav";
import KPICard from "../components/common/KPICard";
import ChartCard from "../components/common/ChartCard";
import StatusStrip from "../components/common/StatusStrip";
import { useDataset } from "../context/DatasetContext";
import * as datasetApi from "../services/datasetApi";
import * as copilotApi from "../services/copilotApi";
import { fmtINR, fmtNum } from "../lib/format";

const CHART_COLORS = ["#F2C811", "#34C7B5", "#FF6B5E", "#6C8CFF", "#B892FF", "#5FD068"];

export default function Dashboard() {
  const { activeDataset } = useDataset();
  const [analytics, setAnalytics] = useState(null);
  const [insight, setInsight] = useState(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [insightErr, setInsightErr] = useState("");

  useEffect(() => {
    if (!activeDataset) return;
    datasetApi.getAnalytics(activeDataset.id).then(setAnalytics);
    fetchInsights();
    // eslint-disable-next-line
  }, [activeDataset]);

  function fetchInsights() {
    if (!activeDataset) return;
    setLoadingInsight(true); setInsightErr("");
    copilotApi.generateInsights(activeDataset.id)
      .then(setInsight)
      .catch((err) => setInsightErr(err.response?.data?.detail || "AI insights need AI_API_KEY configured on the backend."))
      .finally(() => setLoadingInsight(false));
  }

  if (!activeDataset) return <Navigate to="/datasets" replace />;
  if (!analytics) return (<div className="min-h-screen bg-ink text-white"><TopNav /><div className="max-w-6xl mx-auto px-6 py-10 text-slate-400">Loading analytics...</div></div>);

  const { kpis, monthly, breakdowns } = analytics;
  const pieData = (breakdowns.category || []).map((c) => ({ name: c.name, value: c.revenue }));

  return (
    <div className="min-h-screen bg-ink text-white">
      <TopNav />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <h1 className="font-display text-2xl font-semibold mb-1">Good morning 👋</h1>
        <p className="text-slate-400 text-sm mb-6">{fmtNum(kpis.orders)} orders in {activeDataset.name}.</p>

        <div className="grid grid-cols-2 md:grid-cols-6 gap-3 mb-5">
          <KPICard label="Total Revenue" value={fmtINR(kpis.revenue)} />
          <KPICard label="Total Profit" value={fmtINR(kpis.profit)} delta={`${kpis.margin_pct}% margin`} deltaUp={kpis.margin_pct > 0} />
          <KPICard label="Total Orders" value={fmtNum(kpis.orders)} />
          <KPICard label="Customers" value={fmtNum(kpis.customers)} />
          <KPICard label="Avg Order Value" value={fmtINR(kpis.aov)} />
          <KPICard label="Profit Margin" value={`${kpis.margin_pct}%`} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
          <div className="lg:col-span-2">
            <ChartCard title="Revenue & Profit Trend">
              <ResponsiveContainer width="100%" height={260}>
                <LineChart data={monthly}>
                  <CartesianGrid stroke="rgba(255,255,255,0.08)" vertical={false} />
                  <XAxis dataKey="month" stroke="#5C6478" fontSize={11} />
                  <YAxis stroke="#5C6478" fontSize={11} tickFormatter={fmtINR} width={70} />
                  <Tooltip contentStyle={{ background: "#212C43", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 8, fontSize: 12 }} formatter={fmtINR} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Line type="monotone" dataKey="revenue" stroke="#F2C811" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="profit" stroke="#34C7B5" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>
          <ChartCard title="Revenue by Category">
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={85} paddingAngle={2}>
                  {pieData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "#212C43", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 8, fontSize: 12 }} formatter={fmtINR} />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <ChartCard title="Revenue by Region">
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={breakdowns.region || []}>
                <CartesianGrid stroke="rgba(255,255,255,0.08)" vertical={false} />
                <XAxis dataKey="name" stroke="#5C6478" fontSize={11} />
                <YAxis stroke="#5C6478" fontSize={11} tickFormatter={fmtINR} width={70} />
                <Tooltip contentStyle={{ background: "#212C43", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 8, fontSize: 12 }} formatter={fmtINR} />
                <Bar dataKey="revenue" fill="#F2C811" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Top Products">
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={(breakdowns.top_products || []).slice(0, 6)} layout="vertical">
                <CartesianGrid stroke="rgba(255,255,255,0.08)" horizontal={false} />
                <XAxis type="number" stroke="#5C6478" fontSize={11} tickFormatter={fmtINR} />
                <YAxis type="category" dataKey="name" stroke="#5C6478" fontSize={10} width={110} />
                <Tooltip contentStyle={{ background: "#212C43", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 8, fontSize: 12 }} formatter={fmtINR} />
                <Bar dataKey="revenue" fill="#34C7B5" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        <ChartCard title="AI Insights" right={
          <button onClick={fetchInsights} className="text-xs border border-white/15 rounded-lg px-3 py-1.5 flex items-center gap-1.5">
            <RefreshCw size={12} /> Refresh
          </button>
        }>
          {loadingInsight && <StatusStrip text="Analyzing verified metrics..." />}
          {insightErr && <div className="text-coral text-sm">{insightErr}</div>}
          {insight && !loadingInsight && (
            <div>
              <p className="text-sm mb-4">{insight.summary}</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[12.5px]">
                <div>
                  <div className="font-mono text-[10.5px] text-teal uppercase mb-2">Trends</div>
                  {insight.trends?.map((t, i) => <div key={i} className="text-slate-400 mb-1.5">· {t}</div>)}
                </div>
                <div>
                  <div className="font-mono text-[10.5px] text-[#6C8CFF] uppercase mb-2">Opportunities</div>
                  {insight.opportunities?.map((t, i) => <div key={i} className="text-slate-400 mb-1.5">· {t}</div>)}
                </div>
                <div>
                  <div className="font-mono text-[10.5px] text-coral uppercase mb-2">Risks</div>
                  {insight.risks?.map((t, i) => <div key={i} className="text-slate-400 mb-1.5">· {t}</div>)}
                </div>
              </div>
            </div>
          )}
        </ChartCard>
      </div>
    </div>
  );
}
