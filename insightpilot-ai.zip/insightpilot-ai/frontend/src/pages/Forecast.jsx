import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import TopNav from "../components/common/TopNav";
import ChartCard from "../components/common/ChartCard";
import { useDataset } from "../context/DatasetContext";
import * as datasetApi from "../services/datasetApi";
import { fmtINR } from "../lib/format";

export default function Forecast() {
  const { activeDataset } = useDataset();
  const [horizon, setHorizon] = useState(30);
  const [data, setData] = useState(null);

  useEffect(() => {
    if (!activeDataset) return;
    datasetApi.getForecast(activeDataset.id, horizon).then(setData);
  }, [activeDataset, horizon]);

  if (!activeDataset) return <Navigate to="/datasets" replace />;

  const combined = data ? data.forecast.map((f, i) => ({ label: `+${f.period_offset}mo`, forecast: f.value })) : [];

  return (
    <div className="min-h-screen bg-ink text-white">
      <TopNav />
      <div className="max-w-4xl mx-auto px-6 py-8">
        <h1 className="font-display text-xl font-semibold mb-1">Revenue forecast</h1>
        <p className="text-slate-400 text-sm mb-5">Linear trend extrapolation. Not a guarantee — a starting point for planning.</p>

        <div className="flex gap-2 mb-5">
          {[[30, "30 days"], [60, "60 days"], [90, "90 days"]].map(([v, l]) => (
            <div key={v} onClick={() => setHorizon(v)}
              className={`px-3.5 py-2 rounded-lg text-[13px] font-semibold cursor-pointer border ${horizon === v ? "bg-surfaceAlt text-yellow border-white/15" : "text-slate-400 border-white/10"}`}>
              {l}
            </div>
          ))}
        </div>

        {data && (
          <ChartCard title={`Trend: ${data.trend}`}>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={combined}>
                <CartesianGrid stroke="rgba(255,255,255,0.08)" vertical={false} />
                <XAxis dataKey="label" stroke="#5C6478" fontSize={11} />
                <YAxis stroke="#5C6478" fontSize={11} tickFormatter={fmtINR} width={70} />
                <Tooltip contentStyle={{ background: "#212C43", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 8, fontSize: 12 }} formatter={fmtINR} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line type="monotone" dataKey="forecast" stroke="#F2C811" strokeWidth={2} strokeDasharray="5 4" dot />
              </LineChart>
            </ResponsiveContainer>
            <p className="text-xs text-slate-500 mt-3 italic">Ordinary least squares over historical monthly revenue. Actual results may vary with seasonality and promotions.</p>
          </ChartCard>
        )}
      </div>
    </div>
  );
}
