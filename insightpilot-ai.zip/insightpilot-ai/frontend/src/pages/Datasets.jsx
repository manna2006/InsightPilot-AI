import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Upload, CheckCircle2, Loader2 } from "lucide-react";
import TopNav from "../components/common/TopNav";
import EmptyState from "../components/common/EmptyState";
import { useDataset } from "../context/DatasetContext";
import * as datasetApi from "../services/datasetApi";
import { fmtNum } from "../lib/format";

export default function Datasets() {
  const [datasets, setDatasets] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const { setActiveDataset } = useDataset();
  const navigate = useNavigate();

  const refresh = () => datasetApi.listDatasets().then(setDatasets).catch(() => {});
  useEffect(() => { refresh(); }, []);

  async function handleFile(file) {
    if (!file) return;
    setUploading(true); setError(""); setProgress(0);
    try {
      const ds = await datasetApi.uploadDataset(file, setProgress);
      setActiveDataset(ds);
      await refresh();
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.detail || "Upload failed.");
    } finally {
      setUploading(false);
    }
  }

  function selectDataset(ds) {
    setActiveDataset(ds);
    navigate("/dashboard");
  }

  return (
    <div className="min-h-screen bg-ink text-white">
      <TopNav />
      <div className="max-w-4xl mx-auto px-6 py-10">
        <h1 className="font-display text-2xl font-semibold mb-1.5">Datasets</h1>
        <p className="text-slate-400 text-sm mb-8">Upload a CSV, XLSX, or JSON file, or select a previously uploaded dataset.</p>

        <label className="block border-2 border-dashed border-white/15 rounded-xl p-10 text-center cursor-pointer mb-4 hover:border-white/25">
          <input type="file" accept=".csv,.xlsx,.json" className="hidden" onChange={(e) => handleFile(e.target.files[0])} disabled={uploading} />
          {uploading ? <Loader2 className="mx-auto mb-3 animate-spin" size={24} /> : <Upload className="mx-auto mb-3 text-slate-400" size={24} />}
          <div className="text-sm">{uploading ? `Uploading... ${progress}%` : "Drop a file here, or click to browse"}</div>
          <div className="text-xs text-slate-500 mt-1">.csv · .xlsx · .json</div>
        </label>
        {error && <div className="text-coral text-sm mb-6">{error}</div>}

        {datasets.length === 0 ? (
          <EmptyState title="No datasets yet" subtitle="Upload a file above to get started." />
        ) : (
          <div className="bg-surface border border-white/10 rounded-xl divide-y divide-white/10">
            {datasets.map((ds) => (
              <div key={ds.id} className="flex items-center justify-between px-5 py-4 cursor-pointer hover:bg-surfaceAlt" onClick={() => selectDataset(ds)}>
                <div>
                  <div className="text-sm font-medium">{ds.name}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{fmtNum(ds.row_count)} rows · {ds.column_count} columns</div>
                </div>
                <div className="flex items-center gap-2 text-teal text-xs font-mono">
                  <CheckCircle2 size={13} /> {ds.data_quality_score}% quality
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
