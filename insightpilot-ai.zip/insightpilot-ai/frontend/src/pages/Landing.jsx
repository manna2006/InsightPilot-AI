import { Link } from "react-router-dom";
import { MessageSquare, Code2, AlertTriangle, TrendingUp, Users, FileText, ArrowRight } from "lucide-react";

const FEATURES = [
  { icon: MessageSquare, t: "Ask in plain English", d: "Type a business question, get a grounded answer." },
  { icon: Code2, t: "DAX & SQL on demand", d: "Every answer can become a real, validated query." },
  { icon: AlertTriangle, t: "Anomaly detection", d: "Z-score, IQR, and Isolation Forest flag revenue swings." },
  { icon: TrendingUp, t: "Forecasting", d: "Trend projection over your next 30, 60, or 90 days." },
  { icon: Users, t: "RFM segmentation", d: "Sort customers into Champions, At Risk, and more." },
  { icon: FileText, t: "Executive reports", d: "One click turns metrics into a written report." },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-ink text-white">
      <div className="max-w-6xl mx-auto px-6 pt-8 pb-24">
        <div className="flex items-center justify-between mb-16">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-md bg-gradient-to-br from-yellow to-[#C9A20E] flex items-center justify-center text-ink font-bold text-[11px] font-display">IP</div>
            <span className="font-display font-bold text-[13px]">INSIGHTPILOT AI</span>
          </div>
          <div className="flex gap-3">
            <Link to="/login" className="px-4 py-2 rounded-lg border border-white/15 text-sm font-semibold">Log in</Link>
            <Link to="/register" className="px-4 py-2 rounded-lg bg-yellow text-ink text-sm font-semibold">Get started</Link>
          </div>
        </div>

        <div className="max-w-2xl">
          <div className="font-mono text-xs text-teal tracking-wider mb-4">AI-POWERED POWER BI COPILOT</div>
          <h1 className="font-display text-5xl leading-tight font-semibold mb-5">
            Your data. Your questions. <span className="text-yellow">AI-powered answers.</span>
          </h1>
          <p className="text-slate-400 text-lg max-w-xl">
            InsightPilot AI transforms raw business data into dashboards, DAX, insights, forecasts, and actionable recommendations.
          </p>
          <div className="flex gap-3 mt-8">
            <Link to="/register" className="px-6 py-3 rounded-lg bg-yellow text-ink font-semibold flex items-center gap-2">Upload Dataset <ArrowRight size={16} /></Link>
            <Link to="/register" className="px-6 py-3 rounded-lg border border-white/15 font-semibold">Explore Demo</Link>
          </div>
        </div>

        <div className="mt-24">
          <h2 className="font-display text-2xl font-semibold mb-6">Built for the questions analysts actually get asked</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {FEATURES.map(({ icon: Icon, t, d }) => (
              <div key={t} className="bg-surface border border-white/10 rounded-xl p-6">
                <div className="w-8 h-8 rounded-lg bg-surfaceAlt border border-white/10 flex items-center justify-center mb-3.5 text-yellow">
                  <Icon size={16} />
                </div>
                <h3 className="font-display text-[15px] mb-1.5">{t}</h3>
                <p className="text-[13.5px] text-slate-400">{d}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-24 text-center">
          <Link to="/register" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg bg-yellow text-ink font-semibold">
            Create your account <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}
