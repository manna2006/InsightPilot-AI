import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true); setError("");
    try {
      await register(email, password, fullName);
      navigate("/datasets");
    } catch (err) {
      setError(err.response?.data?.detail || "Registration failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-ink text-white flex items-center justify-center px-6">
      <form onSubmit={handleSubmit} className="w-full max-w-sm bg-surface border border-white/10 rounded-2xl p-8">
        <h1 className="font-display text-xl font-semibold mb-6">Create your account</h1>
        {error && <div className="text-coral text-sm mb-4">{error}</div>}
        <label className="block text-xs text-slate-500 mb-1.5">Full name</label>
        <input className="w-full bg-surfaceAlt border border-white/15 rounded-lg px-3 py-2.5 mb-4 text-sm outline-none focus:border-yellow"
          value={fullName} onChange={(e) => setFullName(e.target.value)} />
        <label className="block text-xs text-slate-500 mb-1.5">Email</label>
        <input className="w-full bg-surfaceAlt border border-white/15 rounded-lg px-3 py-2.5 mb-4 text-sm outline-none focus:border-yellow"
          type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <label className="block text-xs text-slate-500 mb-1.5">Password</label>
        <input className="w-full bg-surfaceAlt border border-white/15 rounded-lg px-3 py-2.5 mb-6 text-sm outline-none focus:border-yellow"
          type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} />
        <button disabled={loading} className="w-full py-2.5 rounded-lg bg-yellow text-ink font-semibold text-sm">
          {loading ? "Creating account..." : "Create account"}
        </button>
        <p className="text-xs text-slate-500 mt-4 text-center">
          Already have an account? <Link to="/login" className="text-teal">Log in</Link>
        </p>
      </form>
    </div>
  );
}
