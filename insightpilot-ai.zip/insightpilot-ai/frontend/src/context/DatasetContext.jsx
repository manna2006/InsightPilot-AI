import { createContext, useContext, useState } from "react";

const DatasetContext = createContext(null);

export function DatasetProvider({ children }) {
  const [activeDataset, setActiveDataset] = useState(null); // { id, name, row_count, ... }
  return (
    <DatasetContext.Provider value={{ activeDataset, setActiveDataset }}>
      {children}
    </DatasetContext.Provider>
  );
}

export const useDataset = () => useContext(DatasetContext);
