import { createContext, useContext, useState } from "react";
import * as authApi from "../services/authApi";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(localStorage.getItem("insightpilot_token"));

  async function login(email, password) {
    const { access_token } = await authApi.login(email, password);
    localStorage.setItem("insightpilot_token", access_token);
    setToken(access_token);
  }

  async function register(email, password, fullName) {
    const { access_token } = await authApi.register(email, password, fullName);
    localStorage.setItem("insightpilot_token", access_token);
    setToken(access_token);
  }

  function logout() {
    localStorage.removeItem("insightpilot_token");
    setToken(null);
  }

  return (
    <AuthContext.Provider value={{ token, isAuthenticated: !!token, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
