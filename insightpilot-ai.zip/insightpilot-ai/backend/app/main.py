from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.core.logging import log_requests
from app.database.database import Base, engine
from app.api import auth, datasets, analytics, copilot, dax, anomalies, forecast, customers, reports

settings = get_settings()

app = FastAPI(title=settings.APP_NAME, version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.middleware("http")(log_requests)

app.include_router(auth.router)
app.include_router(datasets.router)
app.include_router(analytics.router)
app.include_router(copilot.router)
app.include_router(dax.router)
app.include_router(anomalies.router)
app.include_router(forecast.router)
app.include_router(customers.router)
app.include_router(reports.router)


@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)


@app.get("/api/health")
def health():
    ai_configured = bool(settings.AI_API_KEY)
    return {"status": "ok", "app": settings.APP_NAME, "ai_provider": settings.AI_PROVIDER, "ai_configured": ai_configured}
