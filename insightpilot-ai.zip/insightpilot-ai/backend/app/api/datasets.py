from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session

from app.api.auth import get_current_user
from app.database.database import get_db
from app.database.models import User, Dataset
from app.schemas.dataset import DatasetOut, DatasetProfile, CleaningRequest
from app.services.data_loader import validate_file, load_dataframe
from app.services.data_profiler import profile_dataset
from app.services.data_cleaner import suggest_cleaning, apply_cleaning
from app.utils.file_utils import save_upload

router = APIRouter(prefix="/api/datasets", tags=["datasets"])


@router.post("/upload", response_model=DatasetOut)
def upload_dataset(file: UploadFile = File(...), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    file_bytes = file.file.read()
    try:
        validate_file(file.filename, len(file_bytes))
    except ValueError as exc:
        raise HTTPException(400, str(exc))

    path = save_upload(file_bytes, file.filename)
    try:
        df = load_dataframe(path)
    except ValueError as exc:
        raise HTTPException(400, str(exc))

    profile = profile_dataset(df)
    dataset = Dataset(
        owner_id=user.id, name=file.filename, file_path=path,
        row_count=profile["row_count"], column_count=profile["column_count"],
        data_quality_score=profile["data_quality_score"],
    )
    db.add(dataset)
    db.commit()
    db.refresh(dataset)
    return dataset


@router.get("", response_model=list[DatasetOut])
def list_datasets(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.query(Dataset).filter(Dataset.owner_id == user.id).order_by(Dataset.uploaded_at.desc()).all()


def _get_owned_dataset(dataset_id: int, db: Session, user: User) -> Dataset:
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id, Dataset.owner_id == user.id).first()
    if not dataset:
        raise HTTPException(404, "Dataset not found.")
    return dataset


@router.get("/{dataset_id}", response_model=DatasetOut)
def get_dataset(dataset_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return _get_owned_dataset(dataset_id, db, user)


@router.get("/{dataset_id}/profile", response_model=DatasetProfile)
def get_profile(dataset_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(dataset_id, db, user)
    df = load_dataframe(dataset.file_path)
    return profile_dataset(df)


@router.get("/{dataset_id}/cleaning-suggestions")
def get_cleaning_suggestions(dataset_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(dataset_id, db, user)
    df = load_dataframe(dataset.file_path)
    return {"suggestions": suggest_cleaning(df)}


@router.post("/{dataset_id}/clean")
def clean_dataset(dataset_id: int, payload: CleaningRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(dataset_id, db, user)
    df = load_dataframe(dataset.file_path)
    cleaned = apply_cleaning(df, payload.accepted_actions)
    return {"row_count_before": len(df), "row_count_after": len(cleaned), "profile": profile_dataset(cleaned)}
