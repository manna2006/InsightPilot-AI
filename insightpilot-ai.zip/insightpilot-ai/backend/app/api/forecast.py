from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.auth import get_current_user
from app.api.datasets import _get_owned_dataset
from app.database.database import get_db
from app.database.models import User
from app.services.data_loader import load_dataframe
from app.services.analytics_engine import compute_monthly_trend
from app.services.forecast_service import linear_forecast

router = APIRouter(prefix="/api/forecast", tags=["forecast"])


@router.post("/{dataset_id}")
def forecast(dataset_id: int, horizon_days: int = Query(30, ge=30, le=90),
             db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(dataset_id, db, user)
    df = load_dataframe(dataset.file_path)
    monthly = compute_monthly_trend(df)
    horizon_periods = max(1, round(horizon_days / 30))
    result = linear_forecast(monthly, horizon_periods)
    return {"horizon_days": horizon_days, **result}
