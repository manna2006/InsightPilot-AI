from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.auth import get_current_user
from app.api.datasets import _get_owned_dataset
from app.database.database import get_db
from app.database.models import User, Report
from app.schemas.reports import ReportRequest, ReportResponse
from app.services.data_loader import load_dataframe
from app.services.report_service import generate_executive_report

router = APIRouter(prefix="/api/reports", tags=["reports"])


@router.post("/generate", response_model=ReportResponse)
def generate(payload: ReportRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(payload.dataset_id, db, user)
    df = load_dataframe(dataset.file_path)
    try:
        content = generate_executive_report(df)
    except RuntimeError as exc:
        raise HTTPException(503, str(exc))
    db.add(Report(dataset_id=dataset.id, content_markdown=content))
    db.commit()
    return ReportResponse(content_markdown=content)
