from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.auth import get_current_user
from app.database.database import get_db
from app.database.models import User, GeneratedDax
from app.schemas.dax import DaxRequest, DaxResponse
from app.services.dax_service import run_dax_request

router = APIRouter(prefix="/api/dax", tags=["dax"])


@router.post("", response_model=DaxResponse)
def dax_copilot(payload: DaxRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if payload.mode not in {"generate", "explain", "debug", "optimize"}:
        raise HTTPException(400, "mode must be one of generate | explain | debug | optimize")
    try:
        result = run_dax_request(payload.mode, payload.input_text)
    except RuntimeError as exc:
        raise HTTPException(503, str(exc))
    db.add(GeneratedDax(dataset_id=None, request=payload.input_text, dax_text=result["dax"], explanation=result["explanation"]))
    db.commit()
    return DaxResponse(**result)
