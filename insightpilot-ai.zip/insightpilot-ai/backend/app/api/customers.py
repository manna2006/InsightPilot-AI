from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.auth import get_current_user
from app.api.datasets import _get_owned_dataset
from app.database.database import get_db
from app.database.models import User
from app.services.data_loader import load_dataframe
from app.services.customer_service import compute_rfm, segment_summary

router = APIRouter(prefix="/api/customers", tags=["customers"])


@router.post("/rfm/{dataset_id}")
def rfm(dataset_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(dataset_id, db, user)
    df = load_dataframe(dataset.file_path)
    rows = compute_rfm(df)
    return {"customers": rows[:100], "segments": segment_summary(rows)}
