from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.auth import get_current_user
from app.api.datasets import _get_owned_dataset
from app.database.database import get_db
from app.database.models import User
from app.services.data_loader import load_dataframe
from app.services.analytics_engine import compute_monthly_trend
from app.services.anomaly_service import run_detection

router = APIRouter(prefix="/api/anomalies", tags=["anomalies"])


@router.post("/detect/{dataset_id}")
def detect(dataset_id: int, method: str = Query("zscore", pattern="^(zscore|iqr|isolation_forest)$"),
           db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(dataset_id, db, user)
    df = load_dataframe(dataset.file_path)
    monthly = compute_monthly_trend(df)
    return {"method": method, "anomalies": run_detection(monthly, method=method)}
