from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.auth import get_current_user
from app.api.datasets import _get_owned_dataset
from app.database.database import get_db
from app.database.models import User
from app.services.data_loader import load_dataframe
from app.services.analytics_engine import compute_kpis, compute_monthly_trend, compute_breakdowns
from app.services.eda_engine import describe, recommend_charts

router = APIRouter(prefix="/api/datasets", tags=["analytics"])


@router.get("/{dataset_id}/analytics")
def get_analytics(dataset_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(dataset_id, db, user)
    df = load_dataframe(dataset.file_path)
    return {
        "kpis": compute_kpis(df),
        "monthly": compute_monthly_trend(df),
        "breakdowns": compute_breakdowns(df),
        "eda": describe(df),
        "recommended_charts": recommend_charts(df),
    }
