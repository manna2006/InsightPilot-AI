from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.auth import get_current_user
from app.api.datasets import _get_owned_dataset
from app.database.database import get_db
from app.database.models import User, ChatMessage, ChatSession, GeneratedQuery
from app.schemas.copilot import ChatRequest, ChatResponse, SqlRequest, SqlResponse, InsightsResponse
from app.services.data_loader import load_dataframe
from app.services.analytics_engine import compute_kpis, compute_monthly_trend, compute_breakdowns
from app.services.ai_service import AIService
from app.services.dax_service import STAR_SCHEMA
from app.utils.validation import validate_readonly_sql

router = APIRouter(prefix="/api/copilot", tags=["copilot"])


def _build_context(dataset, db: Session) -> dict:
    df = load_dataframe(dataset.file_path)
    return {
        "kpis": compute_kpis(df),
        "monthly": compute_monthly_trend(df)[-18:],
        **compute_breakdowns(df),
    }


@router.post("/chat", response_model=ChatResponse)
def chat(payload: ChatRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(payload.dataset_id, db, user)
    context = _build_context(dataset, db)
    try:
        answer = AIService().chat(context, payload.question)
    except RuntimeError as exc:
        raise HTTPException(503, str(exc))

    session = db.query(ChatSession).filter(ChatSession.id == payload.session_id).first() if payload.session_id else None
    if not session:
        session = ChatSession(user_id=user.id, dataset_id=dataset.id, title=payload.question[:60])
        db.add(session); db.commit(); db.refresh(session)
    db.add(ChatMessage(session_id=session.id, role="user", content=payload.question))
    db.add(ChatMessage(session_id=session.id, role="assistant", content=answer))
    db.commit()

    return ChatResponse(answer=answer, suggested_questions=[
        "Why did this happen?", "How does this compare to last period?", "Which segment drives this most?",
    ])


@router.post("/sql", response_model=SqlResponse)
def generate_sql(payload: SqlRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(payload.dataset_id, db, user)
    try:
        raw_sql = AIService().generate_sql(STAR_SCHEMA, payload.question)
    except RuntimeError as exc:
        raise HTTPException(503, str(exc))

    is_safe, reason, safe_sql = validate_readonly_sql(raw_sql)
    db.add(GeneratedQuery(dataset_id=dataset.id, question=payload.question, sql_text=safe_sql, is_safe=is_safe))
    db.commit()
    return SqlResponse(sql=safe_sql, is_safe=is_safe, rejected_reason=reason)


@router.post("/insights", response_model=InsightsResponse)
def insights(payload: SqlRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    dataset = _get_owned_dataset(payload.dataset_id, db, user)
    context = _build_context(dataset, db)
    try:
        result = AIService().generate_insights(context)
    except RuntimeError as exc:
        raise HTTPException(503, str(exc))
    return InsightsResponse(
        summary=result.get("summary", ""), trends=result.get("trends", []),
        opportunities=result.get("opportunities", []), risks=result.get("risks", []),
        recommendations=result.get("recommendations", []),
    )
