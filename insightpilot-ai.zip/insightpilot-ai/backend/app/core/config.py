"""
Application configuration, loaded from environment variables.
Never hard-code secrets here — see /.env.example for required keys.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    APP_NAME: str = "InsightPilot AI"
    ENV: str = "development"

    # Database
    DATABASE_URL: str = "postgresql://insightpilot:insightpilot@db:5432/insightpilot"

    # Auth
    JWT_SECRET: str = "change-me-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 60 * 24

    # AI provider abstraction — swap providers without touching app code
    AI_PROVIDER: str = "claude"          # claude | openai (extend AIProvider to add more)
    AI_API_KEY: str = ""
    AI_MODEL: str = "claude-sonnet-4-6"

    # Uploads
    MAX_UPLOAD_SIZE_MB: int = 50
    ALLOWED_UPLOAD_EXTENSIONS: tuple = (".csv", ".xlsx", ".json")

    # CORS
    CORS_ORIGINS: str = "http://localhost:5173"

    class Config:
        env_file = ".env"
        extra = "ignore"  # a shared .env may also carry frontend-only vars like VITE_API_URL

    @property
    def cors_origins_list(self):
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
