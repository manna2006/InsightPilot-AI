"""
Structured logging. Never log passwords, API keys, tokens, or raw PII —
log identifiers (user id, dataset id) instead of the values themselves.
"""
import logging
import sys
import time
from fastapi import Request

logger = logging.getLogger("insightpilot")
logger.setLevel(logging.INFO)
_handler = logging.StreamHandler(sys.stdout)
_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
if not logger.handlers:
    logger.addHandler(_handler)


async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    duration_ms = round((time.time() - start) * 1000, 1)
    logger.info(f"{request.method} {request.url.path} -> {response.status_code} ({duration_ms}ms)")
    return response
