"""
Computes the aggregate metrics that everything downstream (dashboard,
copilot, reports) is grounded in. This is the ONLY thing sent to the LLM —
never raw rows — per the project's core engineering rule.
"""
import pandas as pd


def _group_sum(df: pd.DataFrame, by: str, revenue_col: str, profit_col: str | None):
    g = df.groupby(by).agg(
        revenue=(revenue_col, "sum"),
        orders=(revenue_col, "count"),
        **({"profit": (profit_col, "sum")} if profit_col and profit_col in df.columns else {}),
    ).reset_index().rename(columns={by: "name"})
    return g.sort_values("revenue", ascending=False).to_dict("records")


def compute_kpis(df: pd.DataFrame, revenue_col="Revenue", profit_col="Profit", customer_col="Customer_ID") -> dict:
    revenue = float(df[revenue_col].sum()) if revenue_col in df else 0.0
    profit = float(df[profit_col].sum()) if profit_col in df.columns else 0.0
    orders = len(df)
    customers = df[customer_col].nunique() if customer_col in df.columns else None
    return {
        "revenue": revenue, "profit": profit, "orders": orders, "customers": customers,
        "aov": round(revenue / orders, 2) if orders else 0,
        "margin_pct": round((profit / revenue) * 100, 2) if revenue else 0,
    }


def compute_monthly_trend(df: pd.DataFrame, date_col="Order_Date", revenue_col="Revenue", profit_col="Profit") -> list[dict]:
    if date_col not in df.columns:
        return []
    d = df.copy()
    d[date_col] = pd.to_datetime(d[date_col], errors="coerce")
    d = d.dropna(subset=[date_col])
    d["month"] = d[date_col].dt.to_period("M").astype(str)
    grouped = d.groupby("month").agg(
        revenue=(revenue_col, "sum"),
        profit=(profit_col, "sum") if profit_col in d.columns else (revenue_col, "sum"),
        orders=(revenue_col, "count"),
    ).reset_index()
    return grouped.sort_values("month").to_dict("records")


def compute_breakdowns(df: pd.DataFrame, revenue_col="Revenue", profit_col="Profit") -> dict:
    out = {}
    for dim in ["Region", "Category", "Customer_Segment"]:
        if dim in df.columns:
            out[dim.lower()] = _group_sum(df, dim, revenue_col, profit_col)
    if "Product_Name" in df.columns:
        out["top_products"] = _group_sum(df, "Product_Name", revenue_col, profit_col)[:10]
    if "Customer_Name" in df.columns:
        out["top_customers"] = _group_sum(df, "Customer_Name", revenue_col, profit_col)[:10]
    return out
