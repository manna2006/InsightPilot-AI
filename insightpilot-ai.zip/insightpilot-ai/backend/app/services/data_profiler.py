"""
Generates a full dataset profile: shape, missing values, duplicates,
per-column statistics, and a composite data-quality score.
"""
import numpy as np
import pandas as pd


def profile_dataset(df: pd.DataFrame) -> dict:
    row_count = len(df)
    col_count = len(df.columns)
    duplicate_rows = int(df.duplicated().sum())
    missing_cells = int(df.isna().sum().sum())

    columns = []
    for col in df.columns:
        series = df[col]
        nulls = int(series.isna().sum())
        is_numeric = pd.api.types.is_numeric_dtype(series)
        entry = {
            "name": col,
            "dtype": "numeric" if is_numeric else ("datetime" if pd.api.types.is_datetime64_any_dtype(series) else "text"),
            "nulls": nulls,
            "null_pct": round((nulls / row_count) * 100, 2) if row_count else 0.0,
            "unique": int(series.nunique(dropna=True)),
            "min": None, "max": None, "mean": None, "median": None, "std": None,
        }
        if is_numeric:
            numeric = series.dropna()
            if len(numeric):
                entry.update({
                    "min": float(numeric.min()), "max": float(numeric.max()),
                    "mean": round(float(numeric.mean()), 2), "median": float(numeric.median()),
                    "std": round(float(numeric.std() or 0), 2),
                })
        columns.append(entry)

    total_cells = row_count * col_count if row_count and col_count else 1
    completeness = 1 - (missing_cells / total_cells)
    uniqueness = 1 - (duplicate_rows / row_count) if row_count else 1
    quality_score = round(max(0.0, min(100.0, (completeness * 0.6 + uniqueness * 0.4) * 100)), 1)

    return {
        "row_count": row_count,
        "column_count": col_count,
        "duplicate_rows": duplicate_rows,
        "missing_cells": missing_cells,
        "data_quality_score": quality_score,
        "memory_usage_kb": round(df.memory_usage(deep=True).sum() / 1024, 1),
        "columns": columns,
    }
