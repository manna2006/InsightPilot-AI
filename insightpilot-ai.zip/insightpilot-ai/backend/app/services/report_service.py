"""Assembles the full data context and calls the AI service to draft a report."""
from app.services.ai_service import AIService
from app.services.analytics_engine import compute_kpis, compute_monthly_trend, compute_breakdowns
from app.services.anomaly_service import run_detection
from app.services.forecast_service import linear_forecast
from app.services.customer_service import compute_rfm, segment_summary
import pandas as pd


def generate_executive_report(df: pd.DataFrame) -> str:
    kpis = compute_kpis(df)
    monthly = compute_monthly_trend(df)
    breakdowns = compute_breakdowns(df)
    anomalies = run_detection(monthly, method="zscore")
    forecast = linear_forecast(monthly)
    rfm_rows = compute_rfm(df) if "Customer_ID" in df.columns else []
    segments = segment_summary(rfm_rows) if rfm_rows else []

    context = {
        "kpis": kpis, "monthly_last_12": monthly[-12:], **breakdowns,
        "anomalies": anomalies[:5], "forecast_trend": forecast["trend"],
        "rfm_segments": segments,
    }
    return AIService().generate_report(context)
