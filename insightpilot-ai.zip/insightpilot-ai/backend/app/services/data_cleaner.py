"""
Suggests (never silently applies) cleaning actions. The caller decides
which suggestions to accept via CleaningRequest.accepted_actions.
Original DataFrame is always preserved; cleaning returns a new copy.
"""
import pandas as pd


def suggest_cleaning(df: pd.DataFrame) -> list[dict]:
    suggestions = []

    for col in df.columns:
        series = df[col]
        null_pct = series.isna().mean() * 100
        if null_pct > 0:
            if pd.api.types.is_numeric_dtype(series):
                suggestions.append({
                    "column": col, "issue": f"{series.isna().sum()} null values ({null_pct:.1f}%)",
                    "suggestion": "Median imputation is recommended.",
                    "action": "impute_median",
                })
            else:
                suggestions.append({
                    "column": col, "issue": f"{series.isna().sum()} null values ({null_pct:.1f}%)",
                    "suggestion": "Mode (most frequent value) imputation is recommended.",
                    "action": "impute_mode",
                })
        if series.dtype == object:
            has_whitespace = series.dropna().astype(str).str.strip().ne(series.dropna().astype(str)).any()
            if has_whitespace:
                suggestions.append({
                    "column": col, "issue": "Leading/trailing whitespace detected.",
                    "suggestion": "Trim whitespace.", "action": "trim_whitespace",
                })

    if df.duplicated().sum() > 0:
        suggestions.append({
            "column": "*", "issue": f"{int(df.duplicated().sum())} duplicate rows detected.",
            "suggestion": "Drop exact duplicate rows.", "action": "drop_duplicates",
        })
    return suggestions


def apply_cleaning(df: pd.DataFrame, accepted_actions: list[str]) -> pd.DataFrame:
    cleaned = df.copy()
    if "drop_duplicates" in accepted_actions:
        cleaned = cleaned.drop_duplicates()
    if "trim_whitespace" in accepted_actions:
        for col in cleaned.select_dtypes(include="object").columns:
            cleaned[col] = cleaned[col].astype(str).str.strip()
    if "impute_median" in accepted_actions:
        for col in cleaned.select_dtypes(include="number").columns:
            cleaned[col] = cleaned[col].fillna(cleaned[col].median())
    if "impute_mode" in accepted_actions:
        for col in cleaned.select_dtypes(include="object").columns:
            mode = cleaned[col].mode()
            if not mode.empty:
                cleaned[col] = cleaned[col].fillna(mode.iloc[0])
    return cleaned
