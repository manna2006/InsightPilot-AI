"""
Exploratory data analysis: descriptive stats, correlations, and
chart-type recommendations based on column type combinations.
"""
import pandas as pd


def describe(df: pd.DataFrame) -> dict:
    numeric = df.select_dtypes(include="number")
    return {
        "descriptive_stats": numeric.describe().round(2).to_dict() if not numeric.empty else {},
        "correlations": numeric.corr().round(2).to_dict() if numeric.shape[1] > 1 else {},
    }


def recommend_charts(df: pd.DataFrame) -> list[dict]:
    """Column-type-driven chart recommendations, matching common BI conventions."""
    recs = []
    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    categorical_cols = df.select_dtypes(include="object").columns.tolist()
    datetime_cols = [c for c in df.columns if "date" in c.lower()]

    if datetime_cols and numeric_cols:
        recs.append({"chart": "line", "x": datetime_cols[0], "y": numeric_cols[0], "reason": "Time + numeric -> trend line"})
    if categorical_cols and numeric_cols:
        recs.append({"chart": "bar", "x": categorical_cols[0], "y": numeric_cols[0], "reason": "Category + numeric -> comparison bar"})
        recs.append({"chart": "donut", "x": categorical_cols[0], "y": numeric_cols[0], "reason": "Category contribution -> donut"})
    if len(numeric_cols) >= 2:
        recs.append({"chart": "scatter", "x": numeric_cols[0], "y": numeric_cols[1], "reason": "Two numeric columns -> scatter"})
    if numeric_cols:
        recs.append({"chart": "histogram", "x": numeric_cols[0], "y": None, "reason": "Single numeric distribution -> histogram"})
    return recs
