"""
Loads CSV / XLSX / JSON into a pandas DataFrame with basic validation.
Raises ValueError with a user-facing message on invalid input — never
lets a corrupt file crash the request.
"""
import json
import os
import pandas as pd

from app.core.config import get_settings

settings = get_settings()


def validate_file(filename: str, size_bytes: int) -> None:
    ext = os.path.splitext(filename)[1].lower()
    if ext not in settings.ALLOWED_UPLOAD_EXTENSIONS:
        raise ValueError(f"Unsupported file type '{ext}'. Allowed: {settings.ALLOWED_UPLOAD_EXTENSIONS}")
    max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
    if size_bytes > max_bytes:
        raise ValueError(f"File exceeds the {settings.MAX_UPLOAD_SIZE_MB}MB upload limit.")
    if size_bytes == 0:
        raise ValueError("The uploaded file is empty.")


def load_dataframe(file_path: str) -> pd.DataFrame:
    ext = os.path.splitext(file_path)[1].lower()
    try:
        if ext == ".csv":
            df = pd.read_csv(file_path)
        elif ext == ".xlsx":
            df = pd.read_excel(file_path)
        elif ext == ".json":
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            df = pd.json_normalize(data if isinstance(data, list) else [data])
        else:
            raise ValueError(f"Unsupported extension: {ext}")
    except (pd.errors.ParserError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Could not parse file — it may be corrupt or misencoded ({exc}).")

    if df.empty:
        raise ValueError("The dataset has no rows after parsing.")
    if len(df.columns) == 0:
        raise ValueError("The dataset has no columns.")
    return df
