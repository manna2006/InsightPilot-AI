"""
Anomaly detection over a numeric series (typically monthly revenue).
Three interchangeable methods: IQR, Z-score, and Isolation Forest.
"""
import numpy as np
from sklearn.ensemble import IsolationForest


def detect_iqr(values: list[float]) -> list[bool]:
    arr = np.array(values, dtype=float)
    q1, q3 = np.percentile(arr, [25, 75])
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    return [bool(v < lower or v > upper) for v in arr]


def detect_zscore(values: list[float], threshold: float = 1.8) -> list[bool]:
    arr = np.array(values, dtype=float)
    mean, std = arr.mean(), arr.std()
    if std == 0:
        return [False] * len(arr)
    z = (arr - mean) / std
    return [bool(abs(v) > threshold) for v in z]


def detect_isolation_forest(values: list[float], contamination: float = 0.1) -> list[bool]:
    arr = np.array(values, dtype=float).reshape(-1, 1)
    if len(arr) < 4:
        return [False] * len(arr)
    model = IsolationForest(contamination=contamination, random_state=42)
    preds = model.fit_predict(arr)
    return [bool(p == -1) for p in preds]


def severity_for(value: float, mean: float, std: float) -> str:
    if std == 0:
        return "Low"
    z = abs((value - mean) / std)
    if z > 2.6:
        return "Critical"
    if z > 2.2:
        return "High"
    if z > 1.8:
        return "Medium"
    return "Low"


def run_detection(monthly: list[dict], method: str = "zscore") -> list[dict]:
    values = [m["revenue"] for m in monthly]
    if not values:
        return []
    mean, std = float(np.mean(values)), float(np.std(values))

    if method == "iqr":
        flags = detect_iqr(values)
    elif method == "isolation_forest":
        flags = detect_isolation_forest(values)
    else:
        flags = detect_zscore(values)

    results = []
    for m, flagged in zip(monthly, flags):
        if not flagged:
            continue
        results.append({
            "period": m.get("month"), "value": m["revenue"],
            "expected_range": [round(mean - std, 2), round(mean + std, 2)],
            "severity": severity_for(m["revenue"], mean, std),
            "reason": "Above trailing average" if m["revenue"] > mean else "Below trailing average",
        })
    return results
