"""
Forecasts future values with ordinary least squares (a dependable, explainable
baseline). Swap in Prophet here for seasonality-aware forecasting if available.
Never claim a forecast is guaranteed — always surface it as a projection.
"""
import numpy as np


def linear_forecast(monthly: list[dict], horizon_periods: int = 3) -> dict:
    values = [m["revenue"] for m in monthly]
    n = len(values)
    if n < 2:
        return {"forecast": [], "trend": "insufficient_data", "slope": 0}

    x = np.arange(n)
    y = np.array(values, dtype=float)
    slope, intercept = np.polyfit(x, y, 1)

    forecast = []
    for h in range(1, horizon_periods + 1):
        yhat = max(0.0, float(intercept + slope * (n - 1 + h)))
        forecast.append({"period_offset": h, "value": round(yhat, 2)})

    trend = "upward" if slope > 0 else "downward" if slope < 0 else "flat"
    # naive +-10% confidence band, clearly not a statistical guarantee
    for f in forecast:
        f["confidence_low"] = round(f["value"] * 0.9, 2)
        f["confidence_high"] = round(f["value"] * 1.1, 2)

    return {"forecast": forecast, "trend": trend, "slope": round(float(slope), 2)}
