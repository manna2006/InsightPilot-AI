"""
Provider-abstracted AI service. The rest of the app calls AIService methods
only — it never imports a provider SDK directly, so swapping AI_PROVIDER in
.env (or adding a new AIProvider subclass) requires no changes elsewhere.
"""
import json
from abc import ABC, abstractmethod

from app.core.config import get_settings
from app.prompts.analyst_prompt import ANALYST_SYSTEM_PROMPT
from app.prompts.sql_prompt import SQL_SYSTEM_PROMPT
from app.prompts.dax_prompt import DAX_SYSTEM_PROMPT
from app.prompts.insight_prompt import INSIGHT_SYSTEM_PROMPT

settings = get_settings()


class AIProvider(ABC):
    @abstractmethod
    def complete(self, system: str, prompt: str, max_tokens: int = 800) -> str:
        ...


class ClaudeProvider(AIProvider):
    def __init__(self, api_key: str, model: str):
        import anthropic
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model

    def complete(self, system: str, prompt: str, max_tokens: int = 800) -> str:
        response = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        return "".join(block.text for block in response.content if block.type == "text").strip()


def _get_provider() -> AIProvider:
    if not settings.AI_API_KEY:
        raise RuntimeError("AI_API_KEY is not set. Add it to your .env file.")
    if settings.AI_PROVIDER == "claude":
        return ClaudeProvider(settings.AI_API_KEY, settings.AI_MODEL)
    raise NotImplementedError(f"AI_PROVIDER '{settings.AI_PROVIDER}' is not implemented. Add a new AIProvider subclass.")


def _safe_json(text: str) -> dict:
    cleaned = text.replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        return {"raw": text}


class AIService:
    def __init__(self):
        self.provider = _get_provider()

    def chat(self, data_context: dict, question: str) -> str:
        prompt = f"DATA_CONTEXT:\n{json.dumps(data_context)}\n\nQuestion: {question}"
        return self.provider.complete(ANALYST_SYSTEM_PROMPT, prompt, max_tokens=500)

    def generate_sql(self, schema_description: str, question: str) -> str:
        prompt = f"Schema:\n{schema_description}\n\nQuestion: {question}"
        return self.provider.complete(SQL_SYSTEM_PROMPT, prompt, max_tokens=300)

    def generate_dax(self, schema_description: str, request_text: str, mode: str = "generate") -> dict:
        mode_instructions = {
            "generate": "Write a new DAX measure for this requirement.",
            "explain": "Explain this existing DAX line by line.",
            "debug": "Find and fix the bug(s) in this DAX.",
            "optimize": "Rewrite this DAX to be more performant.",
        }
        system = DAX_SYSTEM_PROMPT + f'\n\nTask: {mode_instructions.get(mode, mode_instructions["generate"])}' \
                 '\nReturn ONLY JSON: {"dax": "...", "explanation": "..."}'
        prompt = f"Data model:\n{schema_description}\n\nInput:\n{request_text}"
        raw = self.provider.complete(system, prompt, max_tokens=500)
        parsed = _safe_json(raw)
        return {"dax": parsed.get("dax", raw), "explanation": parsed.get("explanation", "")}

    def generate_insights(self, data_context: dict) -> dict:
        prompt = f"DATA_CONTEXT:\n{json.dumps(data_context)}"
        raw = self.provider.complete(INSIGHT_SYSTEM_PROMPT, prompt, max_tokens=700)
        return _safe_json(raw)

    def generate_report(self, data_context: dict) -> str:
        system = (
            "Write an executive report in markdown using ONLY these '## ' headers, in order: "
            "Executive Summary, KPI Summary, Revenue Analysis, Profit Analysis, Customer Analysis, "
            "Product Analysis, Regional Analysis, Anomaly Summary, Forecast, AI Recommendations, Conclusion. "
            "Use only numbers present in DATA_CONTEXT. Keep it under 600 words."
        )
        prompt = f"DATA_CONTEXT:\n{json.dumps(data_context)}"
        return self.provider.complete(system, prompt, max_tokens=1500)

    def explain_result(self, question: str, result_summary: dict) -> str:
        prompt = f"Question: {question}\nResult: {json.dumps(result_summary)}"
        return self.provider.complete(ANALYST_SYSTEM_PROMPT, prompt, max_tokens=300)
