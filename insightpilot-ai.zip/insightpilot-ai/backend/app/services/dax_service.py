"""Thin wrapper tying DAX Copilot requests to the AI service + shared schema description."""
from app.services.ai_service import AIService

STAR_SCHEMA = """Fact table: Sales(Order_ID, Order_Date, Customer_ID, Product_ID, Region, \
Quantity, Unit_Price, Discount, Revenue, Cost, Profit, Payment_Method)
Dimension tables: Date(Date, Month, Quarter, Year), Customer(Customer_ID, Customer_Name, \
Segment, Region, State, City), Product(Product_ID, Product_Name, Category, Sub_Category), \
Region(Region, State, City)"""


def run_dax_request(mode: str, input_text: str) -> dict:
    ai = AIService()
    return ai.generate_dax(STAR_SCHEMA, input_text, mode=mode)
