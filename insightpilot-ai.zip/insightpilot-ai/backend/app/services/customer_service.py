"""
RFM (Recency, Frequency, Monetary) customer segmentation using quantile
scoring — a standard, explainable approach rather than a black-box model.
"""
import pandas as pd


def compute_rfm(df: pd.DataFrame, customer_col="Customer_ID", date_col="Order_Date", revenue_col="Revenue") -> list[dict]:
    d = df.copy()
    d[date_col] = pd.to_datetime(d[date_col], errors="coerce")
    today = d[date_col].max()

    grouped = d.groupby(customer_col).agg(
        last_order=(date_col, "max"),
        frequency=(revenue_col, "count"),
        monetary=(revenue_col, "sum"),
    ).reset_index()
    grouped["recency_days"] = (today - grouped["last_order"]).dt.days

    def score(series, ascending):
        try:
            return pd.qcut(series.rank(method="first"), 5, labels=[1, 2, 3, 4, 5] if ascending else [5, 4, 3, 2, 1]).astype(int)
        except ValueError:
            return pd.Series([3] * len(series), index=series.index)

    grouped["R"] = score(grouped["recency_days"], ascending=False)
    grouped["F"] = score(grouped["frequency"], ascending=True)
    grouped["M"] = score(grouped["monetary"], ascending=True)

    def segment(row):
        if row.R >= 4 and row.F >= 4:
            return "Champions"
        if row.R >= 3 and row.F >= 3:
            return "Loyal Customers"
        if row.R >= 4 and row.F < 3:
            return "Potential Loyalists"
        if row.R == 5 and row.F == 1:
            return "New Customers"
        if row.R <= 2 and row.F >= 3:
            return "At Risk"
        if row.R <= 2 and row.F <= 2:
            return "Lost"
        return "Others"

    grouped["segment"] = grouped.apply(segment, axis=1)
    return grouped.sort_values("monetary", ascending=False).to_dict("records")


def segment_summary(rfm_rows: list[dict]) -> list[dict]:
    df = pd.DataFrame(rfm_rows)
    if df.empty:
        return []
    out = df.groupby("segment").agg(count=("segment", "size"), revenue=("monetary", "sum")).reset_index()
    return out.sort_values("revenue", ascending=False).to_dict("records")
