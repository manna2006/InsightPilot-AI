RECOMMENDATION_SYSTEM_PROMPT = """Given a described business issue and its \
supporting metrics, generate 3-5 concrete, actionable recommendations a \
business team could investigate or execute. Ground every recommendation in \
the supplied metrics — do not recommend actions unrelated to the data shown."""
