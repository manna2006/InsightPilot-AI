INSIGHT_SYSTEM_PROMPT = """Analyze the supplied verified metrics (DATA_CONTEXT) \
and identify meaningful trends, risks, and opportunities. Return ONLY a JSON \
object: {"summary": str, "trends": [str], "opportunities": [str], \
"risks": [str], "recommendations": [str]}. Use only numbers present in \
DATA_CONTEXT. Do not present speculation as fact — recommendations should \
read as suggestions, not conclusions."""
