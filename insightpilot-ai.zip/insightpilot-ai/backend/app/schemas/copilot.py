from typing import List, Optional
from pydantic import BaseModel


class ChatRequest(BaseModel):
    dataset_id: int
    question: str
    session_id: Optional[int] = None


class ChatResponse(BaseModel):
    answer: str
    suggested_questions: List[str] = []


class SqlRequest(BaseModel):
    dataset_id: int
    question: str


class SqlResponse(BaseModel):
    sql: str
    is_safe: bool
    rejected_reason: Optional[str] = None


class InsightsResponse(BaseModel):
    summary: str
    trends: List[str]
    opportunities: List[str]
    risks: List[str]
    recommendations: List[str]
