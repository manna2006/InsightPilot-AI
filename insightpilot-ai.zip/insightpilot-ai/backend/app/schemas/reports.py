from pydantic import BaseModel


class ReportRequest(BaseModel):
    dataset_id: int


class ReportResponse(BaseModel):
    content_markdown: str
