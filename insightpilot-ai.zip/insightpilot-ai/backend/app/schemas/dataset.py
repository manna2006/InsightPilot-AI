from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel


class ColumnProfile(BaseModel):
    name: str
    dtype: str
    nulls: int
    null_pct: float
    unique: int
    min: Optional[float] = None
    max: Optional[float] = None
    mean: Optional[float] = None
    median: Optional[float] = None
    std: Optional[float] = None


class DatasetProfile(BaseModel):
    row_count: int
    column_count: int
    duplicate_rows: int
    missing_cells: int
    data_quality_score: float
    memory_usage_kb: float
    columns: List[ColumnProfile]


class DatasetOut(BaseModel):
    id: int
    name: str
    row_count: int
    column_count: int
    data_quality_score: float
    uploaded_at: datetime

    class Config:
        from_attributes = True


class CleaningSuggestion(BaseModel):
    column: str
    issue: str
    suggestion: str
    action: str    # impute_median | impute_mode | drop_duplicates | trim_whitespace | coerce_type


class CleaningRequest(BaseModel):
    dataset_id: int
    accepted_actions: List[str] = []
