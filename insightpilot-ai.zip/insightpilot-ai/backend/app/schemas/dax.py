from pydantic import BaseModel


class DaxRequest(BaseModel):
    mode: str          # generate | explain | debug | optimize
    input_text: str


class DaxResponse(BaseModel):
    dax: str
    explanation: str
