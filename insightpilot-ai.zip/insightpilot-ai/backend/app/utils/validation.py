"""
SQL safety validation. Only SELECT statements are ever allowed to run —
everything else is rejected before it reaches a database connection.
"""
import re

DESTRUCTIVE_KEYWORDS = ["INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE", "CREATE", "GRANT", "REVOKE"]


def validate_readonly_sql(sql: str, max_rows: int = 1000) -> tuple[bool, str | None, str]:
    """Returns (is_safe, rejection_reason, sql_with_limit_enforced)."""
    cleaned = sql.strip().rstrip(";")
    upper = cleaned.upper()

    for kw in DESTRUCTIVE_KEYWORDS:
        if re.search(rf"\b{kw}\b", upper):
            return False, f"Statement contains a disallowed keyword: {kw}.", cleaned

    if not upper.startswith("SELECT"):
        return False, "Only SELECT statements are permitted.", cleaned

    if ";" in cleaned:
        return False, "Multiple statements are not permitted.", cleaned

    if "LIMIT" not in upper:
        cleaned = f"{cleaned} LIMIT {max_rows}"

    return True, None, cleaned
