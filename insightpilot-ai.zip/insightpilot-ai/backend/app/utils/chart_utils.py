"""Formatting helpers shared by API responses that feed frontend charts."""


def format_currency_inr(value: float) -> str:
    abs_v = abs(value)
    if abs_v >= 1e7:
        return f"₹{value / 1e7:.2f} Cr"
    if abs_v >= 1e5:
        return f"₹{value / 1e5:.2f} L"
    return f"₹{value:,.0f}"
