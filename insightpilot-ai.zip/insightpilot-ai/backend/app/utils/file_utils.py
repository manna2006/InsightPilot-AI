import os
import uuid

UPLOAD_DIR = os.environ.get("UPLOAD_DIR", "/tmp/insightpilot_uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


def save_upload(file_bytes: bytes, original_filename: str) -> str:
    ext = os.path.splitext(original_filename)[1]
    safe_name = f"{uuid.uuid4().hex}{ext}"
    path = os.path.join(UPLOAD_DIR, safe_name)
    with open(path, "wb") as f:
        f.write(file_bytes)
    return path
