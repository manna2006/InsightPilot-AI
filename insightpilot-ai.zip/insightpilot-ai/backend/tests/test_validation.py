from app.utils.validation import validate_readonly_sql


def test_select_is_allowed():
    ok, reason, sql = validate_readonly_sql("SELECT * FROM sales")
    assert ok is True
    assert "LIMIT" in sql


def test_drop_is_rejected():
    ok, reason, _ = validate_readonly_sql("DROP TABLE sales")
    assert ok is False
    assert "DROP" in reason


def test_insert_is_rejected():
    ok, reason, _ = validate_readonly_sql("INSERT INTO sales VALUES (1)")
    assert ok is False


def test_existing_limit_is_preserved():
    ok, reason, sql = validate_readonly_sql("SELECT * FROM sales LIMIT 5")
    assert sql.count("LIMIT") == 1
