import pandas as pd
from app.services.data_profiler import profile_dataset


def test_profile_basic_shape():
    df = pd.DataFrame({"a": [1, 2, None, 4], "b": ["x", "y", "z", "x"]})
    profile = profile_dataset(df)
    assert profile["row_count"] == 4
    assert profile["column_count"] == 2
    assert profile["missing_cells"] == 1
    assert 0 <= profile["data_quality_score"] <= 100


def test_duplicate_detection():
    df = pd.DataFrame({"a": [1, 1, 2], "b": ["x", "x", "y"]})
    profile = profile_dataset(df)
    assert profile["duplicate_rows"] == 1
