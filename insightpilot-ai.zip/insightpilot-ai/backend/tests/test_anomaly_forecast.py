from app.services.anomaly_service import detect_zscore, detect_iqr
from app.services.forecast_service import linear_forecast


def test_zscore_flags_extreme_value():
    values = [100, 102, 98, 101, 400]
    flags = detect_zscore(values, threshold=1.5)
    assert flags[-1] is True


def test_iqr_flags_extreme_value():
    values = [100, 102, 98, 101, 400]
    flags = detect_iqr(values)
    assert flags[-1] is True


def test_forecast_returns_requested_horizon():
    monthly = [{"revenue": v} for v in [100, 110, 120, 130, 140]]
    result = linear_forecast(monthly, horizon_periods=3)
    assert len(result["forecast"]) == 3
    assert result["trend"] == "upward"
